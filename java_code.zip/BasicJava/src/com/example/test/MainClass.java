package com.example.test;

public class MainClass {

	public void shifting(int arr[], int n) {
		int count = 0;
		for (int i = 0; i < 7; i++) {
			try {
				if (arr[i] != 0) {
					arr[count++] = arr[i];
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		while(count<n) {
			arr[count++] = 0;
		}
		for (int i : arr) {
			System.out.println(i);
		}
		
	}

	public static void main(String[] args) {
		int arr[] = { 1, 0, 0, 0, 1, 0, 0 };

		MainClass mai = new MainClass();
		mai.shifting(arr, arr.length);

		Parent parent = new Parent() {

			@Override
			public int size() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public boolean isEmpty() {
				// TODO Auto-generated method stub
				return false;
			}
		};
	}
}
