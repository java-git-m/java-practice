package com.example.test;

public interface Parent {

	int size();
	boolean isEmpty();
}
