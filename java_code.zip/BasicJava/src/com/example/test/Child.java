package com.example.test;

public interface Child extends Parent{


}
