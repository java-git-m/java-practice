package com.example.collection.MutiAttributeSorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyClass {

	public static void main(String[] args) {
		Employee e1 = new Employee(1, "praveen", "BLR", 50000l);
		Employee e2 = new Employee(5, "alok", "BPL", 60000l);
		Employee e3 = new Employee(13, "sunil", "DEL", 90000l);
		Employee e4 = new Employee(14, "kanha", "BPL", 10000l);
		Employee e5 = new Employee(1, "pka", "BPL", 5000l);
		Employee e6 = new Employee(1, "pkumar", "BR", 10000l);
		Employee e7 = new Employee(1900, "aga", "DEL", 90000l);
		Employee e8 = new Employee(19090, "kanha", "BPL", 10000l);
		List<Employee> list = new ArrayList<>();
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		list.add(e5);
		list.add(e6);
		list.add(e7);
		list.add(e8);

		Comparator<Employee> idComparator = new Idcomparator();
		Comparator<Employee> nameComparator = new Namecomparator();
		Comparator<Employee> addressComparator = new Addresscomparator();
		Comparator<Employee> salaryComparator = new Salarycomparator();
		
		EmployeeChainedComparator employeeChainedComparator = new EmployeeChainedComparator(idComparator, nameComparator, addressComparator, salaryComparator);
		
		
		Collections.sort(list, employeeChainedComparator);
		list.forEach(System.out::println);
	}
}
class Idcomparator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if (o1.getId() > o2.getId()) {
			return 1;
		} else if (o1.getId() < o2.getId()) {
			return -1;
		}
		return 0;
	}
	
}

class Namecomparator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		
		return o1.getName().compareTo(o2.getName());
	}
	
}

class Addresscomparator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		
		return o1.getAddress().compareTo(o2.getAddress());
	}
	
}

class Salarycomparator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		
		return o1.getSalary().compareTo(o2.getSalary());
	}
	
}

