package com.example.collection.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class ListCollection {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>();
		Set<String> set = new HashSet<>();
		Queue<String> queue = new PriorityQueue<>();
		SortedSet<String> sortedSet = new TreeSet<>();
		
		NavigableSet<String> navigableSet = new TreeSet<>();
		Set<String> linkedHashSet = new LinkedHashSet<>();
		Map<String, String> map = new HashMap<>(10);
		
		int hashCodeVal = "kumar".hashCode() & (64-1);
		System.out.println(hashCodeVal);
				
	}
}
