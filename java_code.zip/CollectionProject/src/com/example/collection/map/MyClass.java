package com.example.collection.map;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MyClass {
	public static void main(String[] args) {

		Employee e1 = new Employee(11, "praveen", "BLR", 50000l);
		Employee e2 = new Employee(21, "alok", "BPL", 60000l);
		Employee e3 = new Employee(13, "sunil", "DEL", 90000l);
		Employee e4 = new Employee(14, "kanha", "BPL", 10000l);
		Employee e5 = new Employee(91, "praveen", "BLR", 50000l);
		Employee e6 = new Employee(1002, "alok", "BPL", 60000l);
		Employee e7 = new Employee(1900, "sunil", "DEL", 90000l);
		Employee e8 = new Employee(19090, "kanha", "BPL", 10000l);
		//Employee e5 = e4;

		int limit = 16;
		Map<Employee, Employee> map = new LinkedHashMap<>(limit);
		
		map.put(e1, e1);
		map.put(e2, e2);
		map.put(e3, e3);
		map.put(e4, e4);
		map.put(e5, e5);
		map.put(e6, e6);
		map.put(e7, e7);
		map.put(e8, e8);
		
		/*
		 * Iterator<Employee> it = map.keySet().iterator(); while (it.hasNext()) {
		 * Employee employee = (Employee) it.next();
		 * System.out.println(map.get(employee)); }
		 */
		
		
		Set<String> setString = new TreeSet<String>();
		setString.add("Praveen");
		setString.add("Agrawal");
		//setString.add(null);
		/*
		 * Set<Map.Entry<Employee, Employee>> mapEntry = map.entrySet();
		 * for(Map.Entry<Employee, Employee> emp: mapEntry) {
		 * System.out.println(emp.getKey()); System.out.println(emp.getValue()); }
		 */
		System.out.println(setString);
		System.out.println(map.size());
		int oldCapacity = 25;
		int size = (oldCapacity * 3)/2 + 1;
		System.out.println(size);
	}
}
