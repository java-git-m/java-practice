package com.example.streams.methodreference;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class MainClass {
	public static void main(String[] args) {
		
		Employee e1 = new Employee(1, "praveen", "BLR", 50000l);
		Employee e2 = new Employee(2, "alok", "BPL", 60000l);
		Employee e3 = new Employee(3, "sunil", "DEL", 90000l);
		Employee e4 = new Employee(5, "kanha", "BPL", 10000l);
		Employee e5 = new Employee(4, "vikas", "BPL", 20000l);
		List<Employee> list = new ArrayList<>();
		list.add(e3);
		list.add(e1);
		list.add(e2);
		list.add(e5);
		list.add(e4);
		
		//List<Long> productPriceList =   
				list.stream()  
                            .filter(p -> p.getSalary() > 30000) // filtering data  
                            .map(Employee::getSalary)        // fetching price by referring getPrice method  
                            .forEachOrdered(System.out::println);
                            //.collect(Collectors.toList());  // collecting as list  
       // System.out.println(productPriceList);  
	}
}
