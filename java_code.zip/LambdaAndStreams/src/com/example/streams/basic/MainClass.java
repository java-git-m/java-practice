package com.example.streams.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.example.lambda.advanced.comparator.Employee;

public class MainClass {

	public static void main(String[] args) {

		Employee e1 = new Employee(1, "praveen", "BLR", 50000l);
		Employee e2 = new Employee(2, "alok", "BPL", 60000l);
		Employee e3 = new Employee(3, "sunil", "DEL", 90000l);
		Employee e4 = new Employee(5, "kanha", "BPL", 10000l);
		Employee e5 = new Employee(4, "vikas", "BPL", 20000l);
		List<Employee> list = new ArrayList<>();
		list.add(e3);
		list.add(e1);
		list.add(e2);
		list.add(e5);
		list.add(e4);
		
		Predicate<Employee> predicate = new Predicate<Employee>() {
			
			@Override
			public boolean test(Employee t) {
				// TODO Auto-generated method stub
				return t.getSalary()>30000;
			}
		};
		
		Function<Employee, Long> function = new Function<Employee, Long>() {
			
			@Override
			public Long apply(Employee t) {
				// TODO Auto-generated method stub
				Long salary = t.getSalary() + 1;
				return salary;
			}
		};
		
		BinaryOperator<Long> accumulator = new BinaryOperator<Long>() {

			@Override
			public Long apply(Long t, Long u) {
				// TODO Auto-generated method stub
				return t*u;
			}
		};
		
		
		BinaryOperator<Long> accumulator1 = new BinaryOperator<Long>() {

			@Override
			public Long apply(Long t, Long u) {
				// TODO Auto-generated method stub
				return t+u;
			}
		};
		
		List<Long> productPriceList2 = 
				list.stream()
				.filter(t ->  t.getSalary()>30000)// filtering data
				.map(t -> t.getSalary() + 10)
				.collect(Collectors.toList()); // collecting as list
		System.out.println(productPriceList2);
		//System.out.println(list);
		
		Optional<Long> optionalValue = 
				list.stream()
				.filter(t ->  t.getSalary()>30000)// filtering data
				.map(t -> t.getSalary() + 10)
				.reduce(accumulator);
		
		System.out.println(optionalValue.get());
		
		
		Long optionalValue1 = 
				list.stream()
				.filter(t ->  t.getSalary()>30000)// filtering data
				.map(t -> t.getSalary() + 10)
				.reduce(10l, accumulator1);
		
		System.out.println(optionalValue1);

		Long countValue = 
				list.stream()
				.filter(t ->  t.getSalary()>30000)// filtering data
				.map(t -> t.getSalary() + 10).count();
		// collecting as list
		System.out.println(countValue);
		
		List<Long> limitFunction = 
				list.stream()
				.filter(t ->  t.getSalary()>10000)// filtering data
				.map(t -> t.getSalary() + 10).limit(2)
				.collect(Collectors.toList()); // collecting as list
		System.out.println(limitFunction);
		
		
		Long findFirstValue = 
				list.stream()
				.filter(t ->  t.getSalary()>10000)// filtering data
				.map(t -> t.getSalary() + 10).findFirst().get();
	
		System.out.println(findFirstValue);
		
		
		list.stream()
				.filter(t ->  t.getSalary()>10000)// filtering data
				.map(t -> t.getSalary() + 10)
				.forEach(t->System.out.println(t));
		
		List<Long> mapbefore = 
				list.stream()
				.map(t -> t.getSalary() + 10)
				.filter(t ->  t >20000)// filtering data
				
				.collect(Collectors.toList()); // collecting as list
		System.out.println(mapbefore);
	}
}
