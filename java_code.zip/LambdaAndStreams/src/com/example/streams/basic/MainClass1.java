package com.example.streams.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.example.lambda.advanced.comparator.Employee;

public class MainClass1 {

	public static void main(String[] args) {

		Employee e1 = new Employee(1, "praveen", "BLR", 50000l);
		Employee e2 = new Employee(2, "alok", "BPL", 60000l);
		Employee e3 = new Employee(3, "sunil", "DEL", 90000l);
		Employee e4 = new Employee(5, "kanha", "BPL", 10000l);
		Employee e5 = new Employee(4, "vikas", "BPL", 20000l);
		List<Employee> list = new ArrayList<>();
		list.add(e3);
		list.add(e1);
		list.add(e2);
		list.add(e5);
		list.add(e4);

		long totalPrice3 = list.stream().collect(Collectors.summingLong(product -> product.getSalary() ));
		System.out.println(totalPrice3);
		Optional<Employee> employee =  list.stream().min((o1,o2) -> {
				// TODO Auto-generated method stub
				if(o1.getSalary() == o2.getSalary()) {
					return 0;
				}
				else if(o1.getSalary() < o2.getSalary()) {
					return -1;
				}
				else {
					return 1;
				}
		});
		System.out.println(employee);
		
		Function<Employee, Integer> keyMapper = new Function<Employee, Integer>() {

			@Override
			public Integer apply(Employee t) {
				// TODO Auto-generated method stub
				return t.getId();
			}
		}; 
		
		Function<Employee, String> ValueMapper = new Function<Employee, String>() {

			@Override
			public String apply(Employee t) {
				// TODO Auto-generated method stub
				return t.getName();
			}
		}; 
		
		Map<Integer, String> map = list.stream().collect(Collectors.toMap(keyMapper,ValueMapper));
		System.out.println(map);
		
		
		Map<Integer, String> map1 = list.stream().collect(Collectors.toMap(t -> t.getId()
		,t->t.getName()));
		System.out.println(map1);
		
	}
}
