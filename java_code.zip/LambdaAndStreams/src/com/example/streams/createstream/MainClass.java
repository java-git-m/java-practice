package com.example.streams.createstream;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {
		//1.Stream.of()
		//varargs
		Stream<String> streamUsingOf = Stream.of("praveen", "kumar", "agrawal");
		//streamUsingOf.forEach(t->System.out.println(t)); 

		//2.Stream.of(array)
		Stream<String> streamUsingArray = Stream.of(new String[] {"praveen1", "kumar1", "agrawal1"});
		//streamUsingArray.forEach(t->System.out.println(t));
		
		//3.List.stream()
		List<Integer> list = new ArrayList<Integer>();
		for(int i = 1; i< 10; i++){
		      list.add(i);
		}
		Stream<Integer> streamList = list.stream();
		//streamList.forEach(t->System.out.println(t));
		
		//4. Stream.generate() or Stream.iterate()
		Supplier<Integer> s = new Supplier<Integer>() {

			@Override
			public Integer get() {
				// TODO Auto-generated method stub
				return (new Random()).nextInt(100);
			}
		};
		Stream<Integer> streamGenerate = Stream.generate(s).limit(10);
		//streamGenerate.forEach(t->System.out.println(t));
		//TODO
		UnaryOperator<Integer> unaryOperator = new UnaryOperator<Integer>() {

			@Override
			public Integer apply(Integer t) {
				// TODO Auto-generated method stub
				return t*2;
			}
		};
		//Stream<Integer> streamIterate = Stream.iterate(1, unaryOperator).limit(5);
		//streamIterate.forEach(t->System.out.println(t));
		Predicate<Integer> predicate = new Predicate<Integer>() {

			@Override
			public boolean test(Integer t) {
				// TODO Auto-generated method stub
				return t<=1000;
			}
		};
		Stream<Integer> streamIterate = Stream.iterate(10,predicate, unaryOperator).limit(15);
		//streamIterate.forEach(t->System.out.println(t));
		
		//5. Stream of String chars or tokens
		IntStream streamInt = "12345_abcdefg".chars();
		//streamInt.forEach(p -> System.out.println(p));
		
		Stream<String> streamSplit = Stream.of("A$B$C".split("\\$"));
		//streamSplit.forEach(p -> System.out.println(p));
		
		//stream.empty
		Stream<String> emptyStream = Stream.empty();
		emptyStream.forEach(p -> System.out.println(p));
		
		//Stream.concat
		Stream<String> concatStream = Stream.concat(streamUsingOf,streamUsingArray);
		concatStream.forEach(p -> System.out.println(p));
	}
}
