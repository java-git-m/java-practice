package com.example.streams.collectors;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MyClass {

	public static void main(String[] args) {
		//1. Collect Stream elements to a List
		List<Integer> list = new ArrayList<Integer>();
		 
		for(int i = 1; i< 10; i++){
		      list.add(i);
		}
		List<Integer> filterdList = list.stream().filter(t->t%2==0).collect(Collectors.toList());
		//filterdList.forEach(t->System.out.println(t));
		
		//2. Collect Stream elements to an Array
		Integer[] filterdArray = list.stream()
								.filter(t->t%2==0)
								.toArray(Integer[]::new);
		for (Integer integer : filterdArray) {
		//	System.out.println(integer);
		}
		
		//3.toMap
		//4. toSet
	}
}
