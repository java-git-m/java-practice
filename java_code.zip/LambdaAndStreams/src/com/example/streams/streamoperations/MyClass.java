package com.example.streams.streamoperations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MyClass {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("Amitabh");
		list.add("Shekhar");
		list.add("Aman");
		list.add("Rahul");
		list.add("Shahrukh");
		list.add("Salman");
		list.add("Yana");
		list.add("Lokash");
		list.add("Shekhar");
		// 1. Stream.filter()
		List<String> filterdList = list.stream().filter(t -> t.startsWith("A")).collect(Collectors.toList());
		//filterdList.forEach(t->System.out.println(t));

		// 2. Stream.map()
		List<String> mapList = list.stream().map(t -> t.toUpperCase()).collect(Collectors.toList());
		//mapList.forEach(t->System.out.println(t));

		// 3. Stream.sorted()
		List<String> sortedList = list.stream().map(t -> t.toUpperCase()).sorted().collect(Collectors.toList());
		//sortedList.forEach(t->System.out.println(t));

		// Terminal operations
		// 4.Stream.forEach()
		List<String> forEachOp = list.stream().map(t -> t.toUpperCase()).collect(Collectors.toList());
		//forEachOp.forEach(t-> System.out.println(t));

		// 5. Stream.collect()
		List<String> collectOp = list.stream().map(t -> t.toUpperCase()).collect(Collectors.toList());
		//System.out.println(collectOp);

		// 6. Stream.anyMatch()
		boolean anyMatchOP = list.stream().anyMatch(t -> t.startsWith("A"));
		//System.out.println(anyMatchOP);

		// 7. Stream.allMatch()
		boolean allMatchOP = list.stream().allMatch(t -> t.contains("a"));
		//System.out.println(allMatchOP);

		// 8. Stream.noneMatch()
		boolean noneMatchOP = list.stream().noneMatch(t -> t.startsWith("L"));
		//System.out.println(noneMatchOP);

		// Stream.count()
		long countValue = list.stream().filter((s) -> s.startsWith("A")).count();
		//System.out.println(countValue);
		
		//Stream.reduce()
		BinaryOperator<String> accumulator = new BinaryOperator<String>() {

			@Override
			public String apply(String t, String u) {
				// TODO Auto-generated method stub
				return t+"#"+u;
			}
		};
		
		Optional<String> reduceValue = list.stream().reduce((t,u)->t+"#"+u);
		//System.out.println(reduceValue.get());
		
		//Stream.findFirst()
		Optional<String> findFirstOp = list.stream().filter(t->t.startsWith("S")).findFirst();
		//System.out.println(findFirstOp.get());
		
		
		
		//The Stream flatMap() method is used to flatten a Stream of collections to a Stream of objects. The objects are combined from all the collections in the original Stream.
		//The flatMap() operation has the effect of applying a one-to-many transformation to the elements of the Stream and then flattening the resulting elements into a new Stream.
		List<Integer> list1 = Arrays.asList(1,2,3);
		List<Integer> list2 = Arrays.asList(4,5,6);
		List<Integer> list3 = Arrays.asList(7,8,9);
		List<List<Integer>> listOfLists = Arrays.asList(list1, list2, list3);
		//System.out.println(listOfLists);
		Function<List<Integer>,Stream<Integer>> function = new Function<List<Integer>, Stream<Integer>>() {

			@Override
			public Stream<Integer> apply(List<Integer> t) {
				// TODO Auto-generated method stub
				return t.stream();
			}
		};
		
		List<Integer> flatMapOp= listOfLists.stream().flatMap(t ->
				 t.stream()).collect(Collectors.toList());
		//System.out.println(flatMapOp);
		
		
		//Stream distinct()
		// The distinct() returns a new stream consisting of the distinct elements from the given stream. For checking the equality of the stream elements, the equals() method is used.
		List<String> distinctList = list.stream().distinct().collect(Collectors.toList());
		//System.out.println(distinctList);
		
		
		Consumer<Integer> consume = new Consumer<Integer>() {

			@Override
			public void accept(Integer t) {
				System.out.println(t+1);
				
			}
		};
		
		//Stream peek
		List<Integer> peekList = Arrays.asList(1, 2, 3, 4, 5);
		Long count = peekList.stream()
		  .peek( System.out::println )
		  .count(); 
		System.out.println(count);
		
		List<Integer> newList = peekList.stream()
			      .peek(System.out::println)
			      .collect(Collectors.toList());
		System.out.println(newList);
		
		
		//Stream skip
				List<Integer> skipList = Arrays.asList(1, 2, 3, 4, 5);
				List<Integer> skiipList = skipList.stream()
					      .skip(3)
					      .collect(Collectors.toList());
				System.out.println(skiipList);
	}
}
