package com.example.lambda.advanced;

public class MainClass1 {
	public static void main(String[] args) {
		
		Calcuation calcuation = ( a, b) ->  a*b;
		System.out.println(calcuation.calcuate(10, 20));
	}
}
