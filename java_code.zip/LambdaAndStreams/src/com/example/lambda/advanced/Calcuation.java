package com.example.lambda.advanced;

@FunctionalInterface
public interface Calcuation {

	int calcuate(int a, int b);

}
