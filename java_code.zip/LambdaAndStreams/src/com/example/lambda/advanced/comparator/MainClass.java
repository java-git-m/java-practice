package com.example.lambda.advanced.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainClass {

	public static void main(String[] args) {
		
		Employee e1 = new Employee(1, "praveen", "BLR", 50000l);
		Employee e2 = new Employee(2, "alok", "BPL", 60000l);
		Employee e3 = new Employee(3, "sunil", "DEL", 90000l);
		List<Employee> list = new ArrayList<>();
		list.add(e3);
		list.add(e1);
		list.add(e2);
		System.out.println("Sorting on the basis of id...");  
		
		Collections.sort(list);
		
		list.forEach(t->System.out.println(t));
		
		System.out.println("Sorting on the basis of name...");
		
		Collections.sort(list, (o1,o2) -> {
				return o1.name.compareTo(o2.name);
		});
		list.forEach(t->System.out.println(t));
	}
}
