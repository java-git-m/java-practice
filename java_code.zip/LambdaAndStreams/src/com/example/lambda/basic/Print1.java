package com.example.lambda.basic;

public interface Print1 {

	void print(String str);
}
