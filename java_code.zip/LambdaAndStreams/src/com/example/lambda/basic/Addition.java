package com.example.lambda.basic;

public class Addition implements Calcuation{

	@Override
	public void calcuate(int a, int b) {
		System.out.println(a+b);
	}

}
