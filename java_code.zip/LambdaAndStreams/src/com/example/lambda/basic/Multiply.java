package com.example.lambda.basic;

public class Multiply implements Calcuation{

	@Override
	public void calcuate(int a, int b) {
		System.out.println(a*b);
	}

}
