package com.example.lambda.basic;

public class MainClass {

	public static void main(String[] args) {
		Calcuation calcuation1 = (a, b) -> System.out.println(a + b);
		calcuation1.calcuate(50, 40);

		Calcuation calcuation2 = (a, b) -> System.out.println(a - b);
		calcuation2.calcuate(50, 40);
		
		Calcuation calcuationMul = (a, b) -> System.out.println(a * b);
		calcuationMul.calcuate(50, 40);
		
		Calcuation calcuationDiv = (a, b) -> System.out.println(a / b);
		calcuationDiv.calcuate(50, 2);

		calcuationDiv.add(50,20);
		calcuationDiv.multiply(50,20);
		Calcuation.div(50,2);
		
		
		Print print = ()-> {
				// TODO Auto-generated method stub
			System.out.println("Hi");	
			System.out.println("hello");
		};
		print.print();
		
		Print1 print1 = str -> 
			System.out.println(str);	
			
		print1.print("Praveen");
	}
}
