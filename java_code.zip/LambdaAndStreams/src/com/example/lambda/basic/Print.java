package com.example.lambda.basic;

public interface Print {

	void print();
}
