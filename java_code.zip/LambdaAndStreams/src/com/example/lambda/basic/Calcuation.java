package com.example.lambda.basic;

@FunctionalInterface
public interface Calcuation {

	void calcuate(int a, int b);

	default void multiply(int a, int b)
    {
       System.out.println(a*b);
    }
	
	default void add(int a, int b)
    {
       System.out.println(a+b);
    }
	
	static void div(int a, int b)
    {
       System.out.println(a/b);
    }
	
	private void test() {}
}
