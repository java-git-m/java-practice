package com.example;

class Q {
	int number;
	boolean valueset = false;
	public synchronized void produce(int number) {
		if(valueset) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Produce : " + number);
		this.number = number;
		
		valueset = true;
		notify();
		
	}

	public synchronized void consume() {
		if(!valueset) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Consume : " + number);
		valueset = false;
		notify();
	}
}

class Producer implements Runnable {

	Q q;
	int i = 0;

	public Producer(Q q) {
		this.q = q;
		new Thread(this, "Producer Thread").start();
	}

	@Override
	public void run() {
		while (true) {
			q.produce(i++);
			try {
				Thread.sleep(5000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

	}
}

class Consumer implements Runnable {
	Q q;

	public Consumer(Q q) {
		this.q = q;
		new Thread(this, "Producer Thread").start();
	}

	@Override
	public void run() {
		while (true) {
			q.consume();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

	}
}

public class MainClass {
	public static void main(String[] args) {
		Q q = new Q();
		new Producer(q);
		new Consumer(q);
	}
}
