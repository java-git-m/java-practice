package com.example.behavioral.Observer;

public interface Observer {

	void update(Observable obj, Object arg);
}
