package com.example.behavioral.Observer;

public class Observable {

}
