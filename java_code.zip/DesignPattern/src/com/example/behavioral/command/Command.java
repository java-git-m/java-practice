package com.example.behavioral.command;

public interface Command {
    public void execute();
}
