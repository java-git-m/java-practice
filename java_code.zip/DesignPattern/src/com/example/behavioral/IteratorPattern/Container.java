package com.example.behavioral.IteratorPattern;

public interface Container {
	public Iterator getIterator();
}
