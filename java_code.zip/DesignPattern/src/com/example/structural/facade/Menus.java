package com.example.structural.facade;

public interface Menus {

	Menus getMenus();
}
