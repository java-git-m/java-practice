package com.example.structural.flyweight;

public interface Shape {

	void draw();
}

