package com.example.structural.bridge;

public interface Workshop{
    abstract public void work();
}