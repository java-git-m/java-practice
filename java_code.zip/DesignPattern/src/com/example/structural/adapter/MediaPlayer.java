package com.example.structural.adapter;

public interface MediaPlayer {
	public void play(String audioType, String fileName);
}
