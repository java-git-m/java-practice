package com.example.structural.proxy;

public interface Image {
	void display();
}
