package com.example.structural.composite;

public interface Component {

	void showPrice();
}
