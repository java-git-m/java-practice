package com.example.structural.decorator;

public abstract class ToppingsDecorator extends Pizza {
	public abstract String getDescription();
}