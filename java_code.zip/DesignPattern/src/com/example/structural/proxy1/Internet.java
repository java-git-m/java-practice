package com.example.structural.proxy1;

public interface Internet {
	public void connectTo(String serverhost) throws Exception;
}
