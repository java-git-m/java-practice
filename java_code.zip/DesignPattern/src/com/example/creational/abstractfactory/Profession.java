package com.example.creational.abstractfactory;

public interface Profession {

	public void myjob();
}
