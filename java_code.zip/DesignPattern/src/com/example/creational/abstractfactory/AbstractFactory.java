package com.example.creational.abstractfactory;

public abstract class AbstractFactory  {

	abstract Profession getProfession(ProfessionEnum professionEnum);
	
}
