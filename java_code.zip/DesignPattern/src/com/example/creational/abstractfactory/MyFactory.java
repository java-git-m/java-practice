package com.example.creational.abstractfactory;

public class MyFactory {

	
}
