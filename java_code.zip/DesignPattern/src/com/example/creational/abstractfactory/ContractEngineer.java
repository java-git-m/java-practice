package com.example.creational.abstractfactory;

public class ContractEngineer implements Profession {

	@Override
	public void myjob() {
		System.out.println("I am a contract engineer");

	}

}
