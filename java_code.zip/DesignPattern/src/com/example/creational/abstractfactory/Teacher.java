package com.example.creational.abstractfactory;

public class Teacher implements Profession {

	
	@Override
	public void myjob() {
		System.out.println("I am a teacher");

	}

}
