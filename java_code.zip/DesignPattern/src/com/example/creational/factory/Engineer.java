package com.example.creational.factory;

public class Engineer implements Profession {

	@Override
	public void myjob() {
		System.out.println("I am a engineer");

	}

}
