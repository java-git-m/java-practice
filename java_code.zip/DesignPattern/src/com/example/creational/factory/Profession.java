package com.example.creational.factory;

public interface Profession {

	public void myjob();
}
