package com.example.creational.prototype;

public abstract class Profession {

	public abstract Profession copy();
}
