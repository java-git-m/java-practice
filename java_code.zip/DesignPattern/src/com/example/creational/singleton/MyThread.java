package com.example.creational.singleton;

public class MyThread {

	public static void main(String[] args) {
		SingleTonClass singleTonClass1 = SingleTonClass.getInstance();
		SingleTonClass singleTonClass2 = SingleTonClass.getInstance();
		SingleTonThread obj1 = new SingleTonThread(singleTonClass1);
		SingleTonThread obj2 = new SingleTonThread(singleTonClass2);
		Thread t1 = new Thread(obj1);
		t1.start();
		Thread t2 = new Thread(obj2);
		t2.start();
	}
	
	
}

class SingleTonThread implements Runnable{

	SingleTonClass singleTonClass;
	
	public SingleTonThread(SingleTonClass singleTonClass) {
		this.singleTonClass = singleTonClass;
	}
	@Override
	public void run() {
		singleTonClass.print();
		System.out.println(singleTonClass);
		
	}
	
}