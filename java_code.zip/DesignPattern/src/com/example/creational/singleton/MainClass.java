package com.example.creational.singleton;

public class MainClass {

	public static void main(String[] args) {
		SingleTonClass object1 = SingleTonClass.getInstance();
		
		object1.print();
		
		SingleTonClass object2 = SingleTonClass.getInstance();
		
		object2.print();

		System.out.println(object1);
		System.out.println(object2);
	}

}
