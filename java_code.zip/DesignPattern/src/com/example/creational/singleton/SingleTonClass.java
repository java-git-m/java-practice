package com.example.creational.singleton;

public class SingleTonClass {
	
	//Instance object
	private static SingleTonClass singleTonClass = null;
	
	//Default constructor private
	private SingleTonClass(){
		
	}

	public static synchronized SingleTonClass getInstance() {
		if(singleTonClass == null) {
			singleTonClass = new SingleTonClass();
		}
		return singleTonClass;
	}
	
	public void print() {
		System.out.println("hello print");
	}
}
